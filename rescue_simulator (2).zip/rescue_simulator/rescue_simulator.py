import pygame
from src.map_manager import Tablero
from src.visualization import Visualizer

# --- Configuración del Evento de Tick de Simulación ---
# Define un evento personalizado que Pygame disparará periódicamente.
SIM_TICK_EVENT = pygame.USEREVENT + 1 

def main():
    # Inicialización del Tablero y la Visualización
    tablero = Tablero(ancho=40, largo=30)
    tablero.initialization_simulation() # Esto inicializa elementos, vehículos y estrategias
    tablero.set_sim_state("paused")    # Empezamos en pausa esperando el comando 'Play'

    viz = Visualizer(tablero)
    
    # Configura el temporizador para que el evento SIM_TICK_EVENT se dispare 
    # cada 200 milisegundos (5 ticks de simulación por segundo real).
    pygame.time.set_timer(SIM_TICK_EVENT, 200) 
    
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            
            # -----------------------------------------------------------
            # 1. MANEJO DE TECLADO (Play/Pause)
            # -----------------------------------------------------------
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r:
                    # Regenerar mapa
                    tablero.inicializar_elementos_aleatoriamente()
                    tablero.actualizar_matriz()
                elif e.key == pygame.K_v:
                    # Re-spawn de vehículos
                    tablero.inicializar_vehiculos()
                    tablero.actualizar_matriz()
                elif e.key == pygame.K_SPACE:
                    # Alterna entre 'running' y 'paused'
                    tablero.toggle_sim_state() 
            
            # -----------------------------------------------------------
            # 2. EVENTO DE TICK DE SIMULACIÓN
            # -----------------------------------------------------------
            elif e.type == SIM_TICK_EVENT:
                 # Esta función avanza el juego UN solo paso (tick).
                 # Solo se ejecuta si tablero.sim_state es "running".
                 tablero.ejecutar_un_paso_simulacion()
                 
        # -----------------------------------------------------------
        # 3. FASE DE DIBUJO (Se ejecuta 60 veces por segundo - 60 FPS)
        # -----------------------------------------------------------
        viz.pantalla.fill(viz.color_fondo)
        viz.draw_grid()
        viz.draw_from_tablero() # Dibuja la matriz con las posiciones actualizadas
        pygame.display.flip()
        viz.clock.tick(60)

    pygame.quit()    
    
if __name__ == "__main__":
    main()


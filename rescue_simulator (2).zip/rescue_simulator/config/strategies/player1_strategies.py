class Estrategia_J1():
    pass